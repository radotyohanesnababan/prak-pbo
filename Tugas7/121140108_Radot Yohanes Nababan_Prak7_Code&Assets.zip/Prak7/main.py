from tkinter import *
from tkinter import messagebox
import pygame
import os
from tkinter import filedialog

root = Tk()
root.title("Music Player")
root.geometry ("600x400")


class MusicPlayer:
    
    def __init__(self):
        #memakai fungsi listbox tkinter sebagai tempat music yang akan di masukkan oleh pengguna
        self.songlist = Listbox(root, bg="black", fg="white", width=100, height=15)
        self.songlist.pack()     
        
        pygame.init()
        self.songs = []
        self.paused = False
        self.current_song = ""

        #pembuatan frame
        control_frame = Frame(root)
        control_frame.pack()

        #inisialisasi photo play,pause, stop,next, dan previous dari pemutar music
        self.play_button_img = PhotoImage(file='play.png')
        self.pause_button_img = PhotoImage(file='pause.png')
        self.stop_button_img = PhotoImage(file='stop.png')
        self.next_button_img = PhotoImage(file='forward.png')
        self.prev_button_img = PhotoImage(file='backward.png')
    
        #mengontrol frame dari seluruh tkinter 
        self.control_frame = Frame(root)
        self.control_frame.pack()

        #pembuatan tombol yang mengambil foto dari inisialisasi photo sebelumnya
        self.prev_button = Button(control_frame, image=self.prev_button_img, borderwidth=0,command=self.prev_music)
        self.play_button = Button(control_frame, image=self.play_button_img, borderwidth=0,command=self.play_music)
        self.pause_button = Button(control_frame, image=self.pause_button_img, borderwidth=0,command=self.pause_music)
        self.stop_button = Button(control_frame, image=self.stop_button_img, borderwidth=0,command=self.stop_music)
        self.next_button = Button(control_frame, image=self.next_button_img, borderwidth=0,command=self.next_music)

    #menampilkan tombol open music
        self.tombol_buka = Button(control_frame, text="Open", command = self.open_music)
        self.tombol_buka.pack(side=LEFT,padx=5,pady=10)

        #setting posisi dari tombol
        self.prev_button.pack(side=LEFT,padx=5,pady=10)
        self.stop_button.pack(side=LEFT,padx=5,pady=10)
        self.play_button.pack(side=LEFT,padx=5,pady=10)
        self.pause_button.pack(side=LEFT,padx=5,pady=10)
        self.next_button.pack(side=LEFT,padx=5,pady=10)
        
        
        

    #fungsi untuk mengambil music dari komputer(per folder)
    def open_music(self):
        global current_song
        root.directory = filedialog.askdirectory()
        #buka dialog open windows
        for song in os.listdir(root.directory):
                if os.path.splitext(song)[1] == '.mp3':
                    self.songs.append(song)
            
        for song in self.songs:
            self.songlist.insert("end", song)
                
        #fungsi input song ke dalam songlist    
        self.songlist.selection_set(0)
        self.current_song = self.songs[self.songlist.curselection()[0]]
            
        messagebox.showinfo("Jumlah Lagu", f"Jumlah lagu adalah {len(self.songs)}")
        messagebox.showinfo("Lagu saat ini",f"Lagu saat ini adalah {self.current_song}")

    #fungsi putar music
    def play_music(self):        
        global current_song,paused 
        
        if len(self.songs) == 0  : #cek array lagu kosong atau tidak(ada lagu atau tidak)
            messagebox.showwarning("Error", "Silahkan Input Lagu Terlebih Dahulu!")
            raise AttributeError("Silahkan Input Lagu Terlebih Dahulu!") 
            
        if not self.paused:
              pygame.mixer.music.load(os.path.join(root.directory, self.current_song))
              pygame.mixer.music.play()
        else:
            pygame.mixer.music.unpause()
            self.paused = False


    #fungsi next music
    def next_music(self):
        global current_song, paused
        
        try: 
            self.songlist.selection_clear(0, END)
            self.songlist.selection_set(self.songs.index(self.current_song) + 1)
            self.current_song = self.songs[self.songlist.curselection()[0]]
            self.play_music()
            
        except:
            messagebox.showerror("Error", "Ini Lagu Terakhir!")
 
 
 #fungsi prev music
    def prev_music(self):
        global current_song, paused
        
        try: 
            self.songlist.selection_clear(0, END)
            self.songlist.selection_set(self.songs.index(self.current_song) - 1 )
            self.current_song = self.songs[self.songlist.curselection()[0]]
            self.play_music()
            
        except:
            messagebox.showerror("Error", "Ini Lagu Pertama!")
            

              
        
    #fungsi putar music
    def pause_music(self):
        global pause 
        pygame.mixer.music.pause()
        self.paused = True
    #fungsi putar music
    def stop_music(self):
        pygame.mixer.music.stop()
        


app= MusicPlayer()
root.mainloop() 
